﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartshopProduct.Models;

namespace SmartshopProduct.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        SMARTSHOPContext sp = new SMARTSHOPContext();
        // GET: api/Product
        [HttpGet]
        public IEnumerable<Productdetail> Get()
        {
            return sp.Productdetail.FromSql("SPTDISPLAY").ToList();
        }

        [HttpGet]
        [Route("Type")]
        public IEnumerable<Producttype> Type()
        {
            List<Productdetail> prds = sp.Productdetail.FromSql("SPTDISPLAY").ToList();
            var result = from p in prds
                         group p by new { p.ProductType }
                         into mygroup
                         select mygroup.FirstOrDefault();

            List<Producttype> pr = new List<Producttype>();
            foreach (var item in result)
            {
                Producttype p2 = new Producttype();
                p2.ProductType = item.ProductType;
                pr.Add(p2);
            }
            return pr;
        }

        // GET: api/Product/5
        [HttpGet("{id}", Name = "Get")]
        public Productdetail Get(string id)
        {
            return sp.Productdetail.FromSql("SPTSELECTPRODUCT {0}", id).SingleOrDefault();
        }

        // POST: api/Product
        [HttpPost]
        public void Post([FromBody] Productdetail detail)
        {
            try
            {
                string s = DateTime.Now.ToString("yyyy-MM-dd");
                detail.StockAddedDate = Convert.ToDateTime(s);
                sp.Database.ExecuteSqlCommand("SPTADDPRODUCT {0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12}", detail.ProductCode, detail.ProductName, detail.ProductType, detail.Brand, detail.QuantityType, detail.RatePerQuantity, detail.StockCount, detail.StockAddedDate, detail.Aisle, detail.Shelf, detail.DateOfManufacture, detail.DateOfExpiry, detail.ProductImage);
            }
            catch(Exception e)
            {

            }
            
        }

        // PUT: api/Product/5
        [HttpPut("{id}")]
        public void Put(string id, [FromBody] Productdetail detail)
        {
            try
            {
                sp.Database.ExecuteSqlCommand("SPTPRODUCTLOCATIONUPDATE {0}, {1}, {2}", detail.Aisle, detail.Shelf, id);
            }
            catch(Exception e)
            {

            }
            
        }

        [HttpPut("{id}", Name = "Info")]
        [Route("Info/{id}")]
        public void PutInfo(string id, [FromBody] Productdetail detail)
        {
            try
            {
                sp.Database.ExecuteSqlCommand("SPTPRODUCTINFOUPDATE {0}, {1}, {2}, {3}, {4}, {5}", detail.ProductName, detail.StockCount, detail.DateOfManufacture, detail.DateOfExpiry, detail.ProductImage, id);
            }
            catch(Exception e)
            {

            }
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(string id)
        {
            try
            {
                sp.Database.ExecuteSqlCommand("SPTDELETEPRODUCT {0}", id);
            }
            catch (Exception e)
            {

            }
        }
    }
}
