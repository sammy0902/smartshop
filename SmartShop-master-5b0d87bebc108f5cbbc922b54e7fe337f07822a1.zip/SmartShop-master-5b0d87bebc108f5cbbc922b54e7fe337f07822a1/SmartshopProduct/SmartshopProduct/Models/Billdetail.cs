﻿using System;
using System.Collections.Generic;

namespace SmartshopProduct.Models
{
    public partial class Billdetail
    {
        public DateTime PurchaseDate { get; set; }
        public string Userid { get; set; }
        public string ProductCode { get; set; }
        public decimal Quantity { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal Billid { get; set; }

        public Productdetail ProductCodeNavigation { get; set; }
        public Userdetail User { get; set; }
    }
}
