﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace SmartshopProduct.Models
{
    public partial class SMARTSHOPContext : DbContext
    {
        public SMARTSHOPContext()
        {
        }

        public SMARTSHOPContext(DbContextOptions<SMARTSHOPContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Billdetail> Billdetail { get; set; }
        public virtual DbSet<Productdetail> Productdetail { get; set; }
        public virtual DbSet<Userdetail> Userdetail { get; set; }

        // Unable to generate entity type for table 'dbo.OFFERDETAIL'. Please see the warning messages.

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=(local);Database=SMARTSHOP;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Billdetail>(entity =>
            {
                entity.HasKey(e => e.Billid);

                entity.ToTable("BILLDETAIL");

                entity.Property(e => e.Billid)
                    .HasColumnName("BILLID")
                    .HasColumnType("numeric(10, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.ProductCode)
                    .IsRequired()
                    .HasColumnName("PRODUCT_CODE")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PurchaseDate)
                    .HasColumnName("PURCHASE_DATE")
                    .HasColumnType("date");

                entity.Property(e => e.Quantity)
                    .HasColumnName("QUANTITY")
                    .HasColumnType("numeric(3, 0)");

                entity.Property(e => e.TotalAmount)
                    .HasColumnName("TOTAL_AMOUNT")
                    .HasColumnType("numeric(10, 0)");

                entity.Property(e => e.Userid)
                    .IsRequired()
                    .HasColumnName("USERID")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.HasOne(d => d.ProductCodeNavigation)
                    .WithMany(p => p.Billdetail)
                    .HasForeignKey(d => d.ProductCode)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__BILLDETAI__PRODU__145C0A3F");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.Billdetail)
                    .HasForeignKey(d => d.Userid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__BILLDETAI__USERI__1367E606");
            });

            modelBuilder.Entity<Productdetail>(entity =>
            {
                entity.HasKey(e => e.ProductCode);

                entity.ToTable("PRODUCTDETAIL");

                entity.Property(e => e.ProductCode)
                    .HasColumnName("PRODUCT_CODE")
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.Aisle)
                    .IsRequired()
                    .HasColumnName("AISLE")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.Brand)
                    .IsRequired()
                    .HasColumnName("BRAND")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DateOfExpiry)
                    .HasColumnName("DATE_OF_EXPIRY")
                    .HasColumnType("date");

                entity.Property(e => e.DateOfManufacture)
                    .HasColumnName("DATE_OF_MANUFACTURE")
                    .HasColumnType("date");

                entity.Property(e => e.ProductImage)
                    .IsRequired()
                    .HasColumnName("PRODUCT_IMAGE")
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.ProductName)
                    .IsRequired()
                    .HasColumnName("PRODUCT_NAME")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ProductType)
                    .IsRequired()
                    .HasColumnName("PRODUCT_TYPE")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.QuantityType)
                    .HasColumnName("QUANTITY_TYPE")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.RatePerQuantity)
                    .HasColumnName("RATE_PER_QUANTITY")
                    .HasColumnType("numeric(15, 0)");

                entity.Property(e => e.Shelf)
                    .IsRequired()
                    .HasColumnName("SHELF")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.StockAddedDate)
                    .HasColumnName("STOCK_ADDED_DATE")
                    .HasColumnType("date");

                entity.Property(e => e.StockCount)
                    .HasColumnName("STOCK_COUNT")
                    .HasColumnType("numeric(15, 0)");
            });

            modelBuilder.Entity<Userdetail>(entity =>
            {
                entity.HasKey(e => e.Userid);

                entity.ToTable("USERDETAIL");

                entity.Property(e => e.Userid)
                    .HasColumnName("USERID")
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.Age)
                    .HasColumnName("AGE")
                    .HasColumnType("numeric(2, 0)");

                entity.Property(e => e.Contact)
                    .HasColumnName("CONTACT")
                    .HasColumnType("numeric(10, 0)");

                entity.Property(e => e.Firstname)
                    .IsRequired()
                    .HasColumnName("FIRSTNAME")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Gender)
                    .IsRequired()
                    .HasColumnName("GENDER")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Lastname)
                    .IsRequired()
                    .HasColumnName("LASTNAME")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasColumnName("PASSWORD")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.RegistrationStatus)
                    .IsRequired()
                    .HasColumnName("REGISTRATION_STATUS")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.Usertype)
                    .IsRequired()
                    .HasColumnName("USERTYPE")
                    .HasMaxLength(1)
                    .IsUnicode(false);
            });
        }
    }
}
