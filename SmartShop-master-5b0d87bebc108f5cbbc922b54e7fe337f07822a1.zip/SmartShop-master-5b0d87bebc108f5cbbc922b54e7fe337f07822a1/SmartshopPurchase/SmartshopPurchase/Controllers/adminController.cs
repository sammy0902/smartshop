﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartshopPurchase.Models;

namespace SmartshopPurchase.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class adminController : ControllerBase
    {
        SMARTSHOPContext ss = new SMARTSHOPContext();
        public IEnumerable<Productdetail> fetch()
        {
            List<Productdetail> detail = ss.Productdetail.FromSql("SPTDISPLAY").ToList();
            return detail;
        }
        // GET: api/admin
        [HttpGet]
        public IEnumerable<Productdetail> GetSortName()
        {
            var sort = fetch();
            var sortName = sort.OrderBy(x => x.ProductName);
            return sortName;
        }

        [HttpGet]
        [Route("SortPrice")]
        public IEnumerable<Productdetail> GetSortPrice()
        {
            var sort = fetch();
            var sortPrice = sort.OrderBy(x => x.RatePerQuantity);
            return sortPrice;
        }

        [HttpGet]
        [Route("SortAvailability")]
        public IEnumerable<Productdetail> GetSortAvailability()
        {
            var sort = fetch();
            var sortAvailability = sort.OrderByDescending(x => x.StockCount);
            return sortAvailability;
        }

        // GET: api/admin/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/admin
        [HttpPost]
        public void Post([FromBody] Billdetail detail)
        {
            string s = DateTime.Now.ToString("yyyy-MM-dd");
            detail.PurchaseDate = Convert.ToDateTime(s);
            ss.Database.ExecuteSqlCommand("SPTBILLINSERT {0},{1},{2},{3},{4}", detail.PurchaseDate, detail.Userid, detail.ProductCode, detail.Quantity, detail.TotalAmount);
        }

        // PUT: api/admin/5
        [HttpPut("{id}/{count}")]
        public void Put(string id, int count)
        {
            ss.Database.ExecuteSqlCommand("SPTCOUNTUPDATE {0},{1}", count, id);
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
