﻿using System;
using System.Collections.Generic;

namespace SmartshopPurchase.Models
{
    public partial class Productdetail
    {
        public Productdetail()
        {
            Billdetail = new HashSet<Billdetail>();
            PurchaseHistory = new HashSet<PurchaseHistory>();
        }

        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public string ProductType { get; set; }
        public string Brand { get; set; }
        public string QuantityType { get; set; }
        public decimal RatePerQuantity { get; set; }
        public decimal StockCount { get; set; }
        public DateTime StockAddedDate { get; set; }
        public string Aisle { get; set; }
        public string Shelf { get; set; }
        public DateTime DateOfManufacture { get; set; }
        public DateTime DateOfExpiry { get; set; }
        public string ProductImage { get; set; }

        public ICollection<Billdetail> Billdetail { get; set; }
        public ICollection<PurchaseHistory> PurchaseHistory { get; set; }
    }
}
