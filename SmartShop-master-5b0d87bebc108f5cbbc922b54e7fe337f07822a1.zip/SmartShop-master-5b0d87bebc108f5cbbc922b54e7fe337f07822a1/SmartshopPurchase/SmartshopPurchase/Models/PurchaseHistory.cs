﻿using System;
using System.Collections.Generic;

namespace SmartshopPurchase.Models
{
    public partial class PurchaseHistory
    {
        public decimal Purchaseid { get; set; }
        public string Userid { get; set; }
        public string ProductCode { get; set; }
        public int Quantity { get; set; }
        public DateTime PurchaseDate { get; set; }

        public Productdetail ProductCodeNavigation { get; set; }
        public Userdetail User { get; set; }
    }
}
