﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartshopUserRegistration.Models;

namespace SmartshopUserRegistration.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegistrationController : ControllerBase
    {
        SMARTSHOPContext ss = new SMARTSHOPContext();

        public IEnumerable<Userdetail> GetUser()
        {
            List<Userdetail> Users= ss.Userdetail.FromSql("SPTUSERDETAIL").ToList();
            return Users;
        }

        // GET: api/Registration
        [HttpGet]
        public IEnumerable<Userdetail> Get()
        {
            return ss.Userdetail.FromSql("SPTSUPERADMINVIEW").ToList();
        }

        [HttpGet]
        [Route("GetId/{contactNumber}")]
        public UserID GetUserId(decimal contactNumber)
        {
            var userId = GetUser();
            var result = userId.Where(c => c.Contact == contactNumber).Select(p => p.Userid).SingleOrDefault();
            UserID id = new UserID();
            id.Userid = result;
            return id;
        }

        // GET: api/Registration/5
        [HttpGet("{userId}/{password}", Name = "GetUser")]
        public Userdetail Get(string userId, string password)
        {
            return ss.Userdetail.FromSql("SPTUSER {0},{1}", userId, password).SingleOrDefault();
        }

        [HttpGet]
        [Route("Check/{userId}")]
        public Userdetail GetCheck(string userId)
        {
            return ss.Userdetail.FromSql("SPTCHECKUSER {0}", userId).SingleOrDefault();
        }

        // POST: api/Registration
        [HttpPost]
        public void Post([FromBody] Userdetail detail)
        {
            ss.Database.ExecuteSqlCommand("SPTINSERTUSER {0},{1},{2},{3},{4},{5},{6},{7},{8}", detail.Firstname, detail.Lastname, detail.Age, detail.Gender, detail.Contact, detail.Userid,detail.Password,detail.Usertype, detail.RegistrationStatus);

        }

        // PUT: api/Registration/5
        [HttpPut]
        public void Put([FromBody] Userdetail detail)
        {
            ss.Database.ExecuteSqlCommand("SPTADMINSTATUSUPDATE {0}", detail.Userid);
        }

        [HttpPut]
        [Route("Reject")]
        public void PutReject([FromBody] Userdetail detail)
        {
            ss.Database.ExecuteSqlCommand("SPTADMINSTATUSUPDATED {0}", detail.Userid);
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
