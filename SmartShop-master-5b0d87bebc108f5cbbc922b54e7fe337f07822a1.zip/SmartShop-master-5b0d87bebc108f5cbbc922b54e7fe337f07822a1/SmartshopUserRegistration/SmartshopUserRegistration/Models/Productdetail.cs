﻿using System;
using System.Collections.Generic;

namespace SmartshopUserRegistration.Models
{
    public partial class Productdetail
    {
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public string ProductType { get; set; }
        public string Brand { get; set; }
        public string QuantityType { get; set; }
        public decimal RatePerQuantity { get; set; }
        public decimal StockCount { get; set; }
        public DateTime StockAddedDate { get; set; }
        public string Aisle { get; set; }
        public string Shelf { get; set; }
        public DateTime DateOfManufacture { get; set; }
        public DateTime DateOfExpiry { get; set; }
        public string ProductImage { get; set; }
    }
}
