﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SmartshopUserRegistration.Models
{
    public class UserID
    {
        public string Userid { get; set; }
    }
}
