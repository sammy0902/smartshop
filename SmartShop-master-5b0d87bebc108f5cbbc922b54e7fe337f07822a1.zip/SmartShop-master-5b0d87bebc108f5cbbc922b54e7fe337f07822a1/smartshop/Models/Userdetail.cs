﻿using System;
using System.Collections.Generic;

namespace SmartShop.Models
{
    public partial class Userdetail
    {
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public decimal Age { get; set; }
        public string Gender { get; set; }
        public decimal Contact { get; set; }
        public string Userid { get; set; }
        public string Password { get; set; }
        public string Usertype { get; set; }
        public string RegistrationStatus { get; set; }
    }
}
