import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import * as moment from 'moment';
import { IProducts } from 'src/app/Class Files/Product';
import { HomeService } from 'src/app/home.service';
import { UserserviceService } from 'src/app/userservice.service';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {

  add:FormGroup;
  message:string;
  product:IProducts;
  errmessage:string;
  minDate=moment(new Date()).format('YYYY-MM-DD');
  maxDate=moment(new Date()).format('YYYY-MM-DD');

  constructor(private formbuilder:FormBuilder, private home:HomeService, private userService:UserserviceService) 
  {
    this.add=this.formbuilder.group({
    productCode:['',[Validators.required,Validators.pattern("[A-Z0-9]{1,50}")]],
    productName:['',[Validators.required]],
    productType:['',[Validators.required,Validators.pattern("[A-Z]{1,50}")]],
    brand:['',[Validators.required,Validators.pattern("[A-Z][a-z]{1,49}")]],
    quantityType:'',
    ratePerQuantity:['',[Validators.required,Validators.min(1)]],
    stockCount:['',[Validators.required,Validators.min(1)]],
    aisle:['',[Validators.required]],
    shelf:['',[Validators.required]],
    dateOfManufacture:['',[Validators.required]],
    dateOfExpiry:['',[Validators.required]],
    productImage:['',Validators.required],
    })
  }

  ngOnInit() {
  }

  productAdd(add:NgForm)
  {
    if(this.add.valid==true)
    {
      {{debugger}}
      this.home.checkProduct(this.add.value).subscribe(result=>{this.product=result as IProducts;
         if(this.product==null)
        {
          this.home.addProduct(this.add.value).subscribe();
          this.message="Product Added Successfully";
          this.add.reset();
        }
        else
        {
          this.errmessage="Product Code should be unique";
        }});
    }
  }

}
