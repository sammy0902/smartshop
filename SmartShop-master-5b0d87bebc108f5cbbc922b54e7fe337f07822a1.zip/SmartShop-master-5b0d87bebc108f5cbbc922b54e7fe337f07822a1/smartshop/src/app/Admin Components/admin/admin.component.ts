import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { IProducttype, IProducts } from 'src/app/Class Files/Product';
import { HomeService } from 'src/app/home.service';
import { UserserviceService } from 'src/app/userservice.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  flag=false;
  ptdid:string;
  id:string;
  typesort:IProducttype[];
  products:Observable<IProducts[]>;
  sortname:string;
  billflag=false;
  editflag=false;
  deleteflag=false;
  searchproduct:string;
  ptdFlag=false;

  constructor(private homeservice:HomeService, private userService:UserserviceService) 
  {

  }

  ngOnInit() {
    this.products=this.homeservice.getProductDetails();
    this.filtertype();
    this.nullCheck();
  }

  productDelete(ptd:IProducts)
  {
    this.homeservice.deleteProduct(ptd.productCode).subscribe(()=>
    {
      this.products=this.homeservice.getProductDetails();
    });
  }

  onClick(ptd:IProducts)
  {
    if(this.ptdid=ptd.productCode)
    {
      if(this.flag==false)
      {
        this.flag=true;
      }
      else
      {
        this.flag=false;
      }
      this.id=this.ptdid;
    }
  }

  filtertype()
  {
    this.homeservice.getProductType().subscribe(result=>
      {
        this.typesort=result as IProducttype[]
      })
  }
  
  change(selectedValue:any)
  {
    this.sortname=selectedValue;
  }

  onbill()
  {
    if(this.billflag==false)
    {
      this.billflag=true;
    }
    else
    {
      this.billflag=false
    }
  }
  
  onedit()
  {
    if(this.editflag==false)
    {
      this.editflag=true;
    }
    else
    {
      this.editflag=false
    }
  }

  ondelete()
  {
    if(this.deleteflag==false)
    {
      this.deleteflag=true;
    }
    else
    {
      this.deleteflag=false
    }
  }

  nullCheck()
    {
      if(this.products==null)
      {
        this.ptdFlag=true;
      }
    }
}
