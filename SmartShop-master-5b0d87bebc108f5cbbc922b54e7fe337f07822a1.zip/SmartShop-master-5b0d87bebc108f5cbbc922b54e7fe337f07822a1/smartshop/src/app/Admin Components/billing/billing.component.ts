import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators, NgForm } from '@angular/forms';
import { IProducts } from 'src/app/Class Files/Product';
import { IUserId } from 'src/app/Class Files/IUserId';
import { HomeService } from 'src/app/home.service';
import { UserserviceService } from 'src/app/userservice.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-billing',
  templateUrl: './billing.component.html',
  styleUrls: ['./billing.component.css']
})
export class BillingComponent implements OnInit {

  products:IProducts=
  {
    productCode:null,
    productName:null,
    productType:null,
    brand:null,
    quantityType:null,
    ratePerQuantity:null,
    stockCount:null,
    stockAddedDate:null,
    aisle:null,
    shelf:null,
    dateOfManufacture:null,
    dateOfExpiry:null,
    productImage:null
  }
  quantity:number
  customerNumber:number;
  bill:FormGroup
  user:IUserId;
  userFlag=false;
  message:string;
  updatedCount:number;
  billFlag=false;

  constructor(private toast:ToastrService,private homeservice:HomeService, private actroute:ActivatedRoute, private formbuilder:FormBuilder, private userService:UserserviceService) 
  { 
    this.bill=this.formbuilder.group({
      quantity:['',[Validators.required,Validators.min(1)]],
      customerNumber:['',[Validators.required,Validators.pattern("[789][0-9]{9}")]],
      userid:'',
      totalAmount:'',
      productCode:'',
    })
  }

  ngOnInit() 
  {
    this.homeservice.prid=this.actroute.snapshot.paramMap.get('productCode');
    this.homeservice.editProduct(this.homeservice.prid).subscribe(result=>
    {
      this.products=result as IProducts
    });
  }

  getUserId(customerNumber:number)
  {
    this.userService.getId(customerNumber).subscribe(result=>
      {
        this.user=result as IUserId;
        if(this.user.userid!=null)
        {
          this.message="Hi!"
          this.userFlag=true;
        }
        else
        {
          this.message="Worng Contact Number"
        }
        console.log(this.user)
      });
  }

  getBill(bill)
  {
    this.bill.value.userid=this.user.userid;
    this.bill.value.productCode=this.products.productCode;
    this.bill.value.totalAmount=this.products.ratePerQuantity*this.bill.value.quantity;
    this.updatedCount=this.products.stockCount-this.bill.value.quantity;
    this.saveBill(bill);
    this.updateCount(this.updatedCount);
    this.toast.success('Paid')
  }

  saveBill(bill:NgForm)
  {
    this.userService.billGenerate(this.bill.value).subscribe();
  }

  updateCount(updatedCount:number)
  {
    {{debugger}}
    this.homeservice.countUpdate(updatedCount).subscribe();
    this.billFlag=true;
  }

}

