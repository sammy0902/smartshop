import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import { IProducts } from 'src/app/Class Files/Product';
import { HomeService } from 'src/app/home.service';
import { UserserviceService } from 'src/app/userservice.service';


@Component({
  selector: 'app-editdetail',
  templateUrl: './editdetail.component.html',
  styleUrls: ['./editdetail.component.css']
})
export class EditdetailComponent implements OnInit {

  product:IProducts=
  {
    productCode:null,
    productName:null,
    productType:null,
    brand:null,
    quantityType:null,
    ratePerQuantity:null,
    stockCount:null,
    stockAddedDate:null,
    aisle:null,
    shelf:null,
    dateOfManufacture:null,
    dateOfExpiry:null,
    productImage:null
  }
  info:FormGroup;
  message:string;

  constructor(private actroute:ActivatedRoute,private home:HomeService, private formbuider:FormBuilder, private route:Router, private userService:UserserviceService) 
  { 
    this.info=this.formbuider.group(
      {
        productName:['',Validators.required],
        stockCount:['',Validators.required],
        dateOfManufacture:['',Validators.required],
        dateOfExpiry:['',Validators.required],
        productImage:['',Validators.required]
      }
    )
  }

  ngOnInit() 
  {
    {{debugger}}
    this.home.prid=this.actroute.snapshot.paramMap.get('productCode');
    this.home.editProduct(this.home.prid).subscribe(result=>
      {
        this.product=result as IProducts
      });
  }

  onSave(info:NgForm)
  {
    {{debugger}}
    this.home.editInfo(info.value).subscribe();
  }

}
