import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HomeService } from 'src/app/home.service';
import { FormGroup, FormBuilder, Validators, NgForm } from '@angular/forms';
import { IProducts } from 'src/app/Class Files/Product';
import { UserserviceService } from 'src/app/userservice.service';

@Component({
  selector: 'app-editlocation',
  templateUrl: './editlocation.component.html',
  styleUrls: ['./editlocation.component.css']
})
export class EditlocationComponent implements OnInit {

  product:IProducts=
  {
    productCode:null,
    productName:null,
    productType:null,
    brand:null,
    quantityType:null,
    ratePerQuantity:null,
    stockCount:null,
    stockAddedDate:null,
    aisle:null,
    shelf:null,
    dateOfManufacture:null,
    dateOfExpiry:null,
    productImage:null
  }
  location:FormGroup
  

  constructor(private actroute:ActivatedRoute,private home:HomeService, private formbuider:FormBuilder, private route:Router, private userService:UserserviceService) 
  { 
    this.location=this.formbuider.group(
      {
        aisle:['',Validators.required],
        shelf:['',Validators.required]
      }
    )
  }

  ngOnInit() 
  {
    this.home.prid=this.actroute.snapshot.paramMap.get('productCode');
    this.home.editProduct(this.home.prid).subscribe(result=>
      {
        this.product=result as IProducts
      })
  }

  onSave(location:NgForm)
  {
    {{debugger}}
    this.home.editLocation(this.location.value).subscribe()
  }

}
