export interface IUserId
{
    userid:string;
}

export interface BillDetail
{
    userid:string;
    productCode:string;
    quantity:number;
    totalAmount:number;
}