export interface IProducts
{
    productCode?:string;
    productName?:string;
    productType?:string;
    brand?:string;
    quantityType?:string;
    ratePerQuantity?:number;
    stockCount?:number;
    stockAddedDate?:Date;
    aisle?:string;
    shelf?:string;
    dateOfManufacture?:Date;
    dateOfExpiry?:Date;
    productImage?:string;
}

export interface IProducttype
{
    productType:string;
}