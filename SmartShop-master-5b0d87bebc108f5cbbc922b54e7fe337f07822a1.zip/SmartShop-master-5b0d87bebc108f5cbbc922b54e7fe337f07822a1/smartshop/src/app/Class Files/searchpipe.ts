import { PipeTransform, Pipe } from '@angular/core';
import { IProducts } from './Product';


@Pipe({
    name:'namesearch'
})
 
export class namesearch implements PipeTransform
{
    transform(product:IProducts[],searchproduct:string)
    {
        if(!product ||!searchproduct)
        {
            return product
        }
        return product.filter(x=>x.productName.toLowerCase().startsWith(searchproduct.toLowerCase()));
    }
}

@Pipe({
    name:'sortbyproducttype'
})

export class sortbyproducttype implements PipeTransform
{
    transform(sortproduct:IProducts[],typesort:string)
    {
        if(!sortproduct ||!typesort)
        {
            return sortproduct
        }
        return sortproduct.filter(x=>x.productType.toLowerCase().startsWith(typesort.toLowerCase()));
    }
}