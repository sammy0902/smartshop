export interface IUser
{
    firstname?:string;
    lastname?:string;
    age?:number;
    gender?:string;
    contact?:number;
    userid:string;
    password?:string;
    usertype?:string;
    registrationStatus?:string;   
}