import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { IProducts } from '../../Class Files/Product';
import { HomeService } from 'src/app/home.service';
import { UserserviceService } from 'src/app/userservice.service';


@Component({
  selector: 'app-getproduct',
  templateUrl: './getproduct.component.html',
  styleUrls: ['./getproduct.component.css']
})
export class GetproductComponent implements OnInit {

  product:IProducts=
  {
    productCode:null,
    productName:null,
    productType:null,
    brand:null,
    quantityType:null,
    ratePerQuantity:null,
    stockCount:null,
    stockAddedDate:null,
    aisle:null,
    shelf:null,
    dateOfManufacture:null,
    dateOfExpiry:null,
    productImage:null
  }

  constructor(private home:HomeService, private actroute:ActivatedRoute, private userService:UserserviceService) { }

  ngOnInit() 
  {
    {{debugger}}
    this.home.prid=this.actroute.snapshot.paramMap.get('productCode');
    this.home.editProduct(this.home.prid).subscribe(result=>
      {
        this.product=result as IProducts
      })
  }

}
