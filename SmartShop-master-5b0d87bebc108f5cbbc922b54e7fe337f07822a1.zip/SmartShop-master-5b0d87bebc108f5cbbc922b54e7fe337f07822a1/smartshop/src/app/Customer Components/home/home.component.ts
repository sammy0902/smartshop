import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { IProducts } from '../../Class Files/Product';
import { HomeService } from 'src/app/home.service';
import { UserserviceService } from 'src/app/userservice.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  searchproduct:string;
  productFlag=false;

  constructor(private homeservice:HomeService, private userService:UserserviceService) { }

  Products:Observable<IProducts[]>
  
  ngOnInit() {
    this.Products=this.homeservice.getProductDetails();
    console.log(this.userService.user.userid)
    this.sortName();
    this.sortPrice();
    this.sortAvailability();
    console.log(this.Products)
  }

  sortName()
  {
    this.Products=this.homeservice.nameSort();
  }

  sortPrice()
  {
    this.Products=this.homeservice.priceSort();
  }

  sortAvailability()
  {
    this.Products=this.homeservice.availabilitySort();
  }

}
