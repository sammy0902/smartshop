import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, NgForm } from '@angular/forms';

import { Router } from '@angular/router';
import { UserserviceService } from 'src/app/userservice.service';
import { IUser } from 'src/app/Class Files/user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private formbuilder:FormBuilder,private userservice:UserserviceService,private route:Router) {
    this.login=this.formbuilder.group({
      userid:['',Validators.required],
      password:['',Validators.required]
    })
   }

   message:string;

  login:FormGroup;
  user:IUser;

  onlogin(login:NgForm)
  {
    console.log(this.login.valid);
    if(this.login.valid)
    {
      this.userservice.loginUser(this.login.value).subscribe(result=>{this.user=result as IUser;
      console.log(this.login.value);
      console.log(this.user)
      this.userservice.user=this.user
      if(this.user!=null && this.user.usertype=='U')
      {
        this.route.navigate(['home']);
      }
      else if (this.user!=null && this.user.usertype=='S' && this.user.registrationStatus=='A') 
      {
        
        this.route.navigate(['superadmin']);
      }
      else if (this.user!=null && this.user.usertype=='A' && this.user.registrationStatus=='P') 
      {
        this.message="Your request is still Pending"
      }
      else if (this.user!=null && this.user.usertype=='A' && this.user.registrationStatus=='D') 
      {
        this.message="Your request was deneid"
      }
      else if (this.user!=null && this.user.usertype=='A' && this.user.registrationStatus=='A') 
      {
        this.route.navigate(['admin'])
      }
      else
      {
        this.message="Invalid Username or Password";
      }
    });
    }
    
  }
  
  ngOnInit() {
  }

}
