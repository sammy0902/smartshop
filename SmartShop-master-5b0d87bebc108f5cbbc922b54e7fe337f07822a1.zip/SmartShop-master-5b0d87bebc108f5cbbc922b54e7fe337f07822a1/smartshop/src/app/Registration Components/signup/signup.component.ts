import { Component, OnInit,ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, NgForm, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { __values } from 'tslib';
import { UserserviceService } from 'src/app/userservice.service';
import { IUser } from 'src/app/Class Files/user';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private formbuild:FormBuilder, private route:Router,private userservice:UserserviceService) { 

    this.signup=this.formbuild.group({
      firstname:['',[Validators.required,Validators.pattern('[A-Za-z]{1,50}')]],
      lastname:['',[Validators.required,Validators.pattern('[A-Za-z]{1,50}')]],
      age:['',[Validators.required,Validators.pattern("[1-9][0-9]{1}")]],
      gender:['',[Validators.required]],
      contact:['',[Validators.required,Validators.pattern("[789][0-9]{9}")]],
      userid:['',[Validators.required,Validators.maxLength(15)]],
      password:['',[Validators.required,Validators.minLength(9),Validators.maxLength(15)]],
      usertype:['',[Validators.required]],
      registrationStatus:''
    })

  }

  url='http://localhost:30351/api/Registration';

  signup:FormGroup;
  user:IUser;
  errmessage:string;
  

  ngOnInit() { }
   

  onsignup(signup:NgForm)
  {
    {{debugger}}
    console.log(this.signup.value)
    if(this.signup.valid==true)
    {
      this.userservice.checkUser(this.signup.value).subscribe(result =>
        {
          this.user=result as IUser;
          if(this.user==null)
          {
            this.userservice.registerUser(this.signup.value).subscribe();
            this.route.navigate(['login']);
          }
          else
          {
            this.errmessage="User Already Exist";
          }
        });
    }
  }

  change(valueSelected:any)
  {
    if(valueSelected=='U')
    {
      this.signup.value.registrationStatus='A'
    }
    else
    {
      this.signup.value.registrationStatus='P'
    }
  }

}
