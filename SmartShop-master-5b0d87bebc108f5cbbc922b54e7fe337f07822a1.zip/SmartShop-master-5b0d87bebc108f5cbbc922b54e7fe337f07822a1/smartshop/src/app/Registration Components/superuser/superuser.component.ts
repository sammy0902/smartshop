import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { IUser } from 'src/app/Class Files/user';
import { UserserviceService } from 'src/app/userservice.service';

@Component({
  selector: 'app-superuser',
  templateUrl: './superuser.component.html',
  styleUrls: ['./superuser.component.css']
})
export class SuperuserComponent implements OnInit {

  User:Observable<IUser[]>

  constructor(private userservice:UserserviceService) { }

  ngOnInit() 
  {
    this.User=this.userservice.getAdmin();
  }

  acceptAdmin(usr:IUser)
  {
    {{debugger}}
    this.userservice.statusApprove(usr).subscribe(()=>
    {
      this.User=this.userservice.getAdmin();
    }
    );
  }

  denyAdmin(usr:IUser)
  {
    this.userservice.statusDeny(usr).subscribe(()=>
    {
      this.User=this.userservice.getAdmin();
    }
  );
  }
}
