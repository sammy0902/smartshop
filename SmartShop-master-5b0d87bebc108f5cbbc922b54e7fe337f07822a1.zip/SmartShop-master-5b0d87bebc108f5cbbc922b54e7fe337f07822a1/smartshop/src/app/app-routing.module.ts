import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './Customer Components/home/home.component';
import { LoginComponent } from './Registration Components/login/login.component';
import { SignupComponent } from './Registration Components/signup/signup.component';
import { SuperuserComponent } from './Registration Components/superuser/superuser.component';
import { AdminComponent } from './Admin Components/admin/admin.component';
import { EditlocationComponent } from './Admin Components/editlocation/editlocation.component';
import { EditdetailComponent } from './Admin Components/editdetail/editdetail.component';
import { AddproductComponent } from './Admin Components/addproduct/addproduct.component';
import { GetproductComponent } from './Customer Components/getproduct/getproduct.component';
import { BillingComponent } from './Admin Components/billing/billing.component';



const routes: Routes = [
  {
    path:'home',
    component:HomeComponent
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'signup',
    component:SignupComponent
  },
  {
    path:'superadmin',
    component:SuperuserComponent
  },
  {
    path:'admin',
    component:AdminComponent
  },
  {
    path:'editlocation/:productCode',
    component:EditlocationComponent
  },
  {
    path:'editdetail/:productCode',
    component:EditdetailComponent
  },
  {
    path:'addproduct',
    component:AddproductComponent
  },
  {
    path:'getproduct/:productCode',
    component:GetproductComponent
  },
  {
    path:'billing/:productCode',
    component:BillingComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes),RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
