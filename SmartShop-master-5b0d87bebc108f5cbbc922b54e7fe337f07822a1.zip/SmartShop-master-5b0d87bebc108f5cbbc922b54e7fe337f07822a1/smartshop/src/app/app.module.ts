import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {ReactiveFormsModule, FormsModule} from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { namesearch, sortbyproducttype } from './Class Files/searchpipe';
import { HomeComponent } from './Customer Components/home/home.component';
import { LoginComponent } from './Registration Components/login/login.component';
import { SignupComponent } from './Registration Components/signup/signup.component';
import { SuperuserComponent } from './Registration Components/superuser/superuser.component';
import { AdminComponent } from './Admin Components/admin/admin.component';
import { AddproductComponent } from './Admin Components/addproduct/addproduct.component';
import { EditlocationComponent } from './Admin Components/editlocation/editlocation.component';
import { EditdetailComponent } from './Admin Components/editdetail/editdetail.component';
import { GetproductComponent } from './Customer Components/getproduct/getproduct.component';
import { BillingComponent } from './Admin Components/billing/billing.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
 
import { ToastrModule } from 'ngx-toastr';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    SignupComponent,
    namesearch,
    sortbyproducttype,
    SuperuserComponent,
    AdminComponent,
    AddproductComponent,
    EditlocationComponent,
    EditdetailComponent,
    GetproductComponent,
    BillingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot()

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
