import { Injectable } from '@angular/core';
import { Observable} from 'rxjs';
import {HttpClient, HttpHeaders} from '@angular/common/http'
import { IUser } from './Class Files/user';
import { IProducts, IProducttype } from './Class Files/Product';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  prid:string;
  constructor(private http:HttpClient) { }

  url='http://localhost:18535/api/user';

  urlsort='http://localhost:5327/api/admin';

  user:Observable<IUser>

  getProductDetails():Observable<IProducts[]>
  {
    return this.http.get<IProducts[]>(this.url);
  }

  nameSort():Observable<IProducts[]>
  {
    return this.http.get<IProducts[]>(this.urlsort);
  }

  priceSort():Observable<IProducts[]>
  {
    return this.http.get<IProducts[]>(this.urlsort+'/SortPrice');
  }
  
  availabilitySort():Observable<IProducts[]>
  {
    return this.http.get<IProducts[]>(this.urlsort+'/SortAvailability');
  }

  deleteProduct(id:string)
  {
    return this.http.delete<IProducts>(this.url+'/'+id);
  }

  editProduct(id:string)
  {
    return this.http.get<IProducts>(this.url+'/'+id);
  }

  addProduct(product:IProducts)
  {
    const detail:IProducts={
      productCode:product.productCode,
      productName:product.productName,
      productType:product.productType,
      brand:product.brand,
      quantityType:product.quantityType,
      ratePerQuantity:product.ratePerQuantity,
      stockCount:product.stockCount,
      aisle:product.aisle,
      shelf:product.shelf,
      dateOfManufacture:product.dateOfManufacture,
      dateOfExpiry:product.dateOfExpiry,
      productImage:product.productImage
    }

    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };
    return this.http.post<IProducts>(this.url,detail,httpOptions);
  }

  checkProduct(product:IProducts)
  {
    const prod:IProducts={
      productCode:product.productCode
    }
     return this.http.get<IProducts>(this.url+'/'+prod.productCode);
  }

  editLocation(prod:IProducts)
  {
    const location:IProducts={
      aisle:prod.aisle,
      shelf:prod.shelf
    }
    return this.http.put<IProducts>(this.url+'/EditLocation/'+this.prid,location);
  }

  editInfo(prod:IProducts)
  {
    const info:IProducts={
      productName:prod.productName,
      stockCount:prod.stockCount,
      dateOfManufacture:prod.dateOfManufacture,
      dateOfExpiry:prod.dateOfExpiry,
      productImage:prod.productImage
    }

    return this.http.put<IProducts>(this.url+'/Info/'+this.prid,info);
  }

  getProductType()
  {
    return this.http.get<IProducttype[]>(this.url+'/type');
  }

  productDetails(id:string)
  {
    return this.http.get<IProducts>(this.url+'/'+id)
  }

  insertHostory(productId:string, userId:string)
  {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };
    return this.http.post<IProducts>(this.urlsort,productId+userId,httpOptions);
  }

  countUpdate(count:number):Observable<IProducts>
  { 
    {{debugger}}
    // count:pr
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };
    return this.http.put<IProducts>(this.urlsort+'/'+this.prid+'/'+count,httpOptions);
  }

}
