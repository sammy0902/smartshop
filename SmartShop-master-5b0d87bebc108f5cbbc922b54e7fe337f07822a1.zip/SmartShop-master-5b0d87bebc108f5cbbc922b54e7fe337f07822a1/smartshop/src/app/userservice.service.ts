import { Injectable } from '@angular/core';
import { IUser } from './Class Files/user';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IUserId, BillDetail } from './Class Files/IUserId';

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {

  user:IUser;

  constructor(private Http:HttpClient) { }

  url='http://localhost:30351/api/Registration';

  urlsort='http://localhost:5327/api/admin';

  registerUser(user:IUser)
  {
    {{debugger}}
    const detail:IUser={
      firstname: user.firstname,
      lastname: user.lastname,
      age: user.age,
      gender: user.gender,
      contact: user.contact,
      userid: user.userid,
      password: user.password,
      usertype: user.usertype,
      registrationStatus: user.registrationStatus
    }
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };
    return this.Http.post(this.url,detail,httpOptions);
  }

  loginUser(user:IUser):Observable<IUser>
  {
    const userdetail:IUser={
      userid:user.userid,
      password:user.password
    }
    return this.Http.get<IUser>(this.url+'/'+userdetail.userid+'/'+userdetail.password);
  }

  getAdmin():Observable<IUser[]>
  {
    return this.Http.get<IUser[]>(this.url);
  }

  statusApprove(userdetail:IUser)
  {
    {{debugger}}
    return this.Http.put<IUser>(this.url,userdetail);
  }

  statusDeny(userdetail:IUser)
  {
    return this.Http.put<IUser>(this.url+'/Reject',userdetail);
  }

  checkUser(user:IUser)
  {
    const usr:IUser={
      userid:user.userid
    }
   return this.Http.get<IUser>(this.url+'/Check/'+usr.userid);
  }

  getId(customerNumber:number)
  {
    return this.Http.get(this.url+'/getid/'+customerNumber)
  }

  billGenerate(userBill:BillDetail)
  {
    const detail:BillDetail={
      userid:userBill.userid,
      totalAmount:userBill.totalAmount,
      productCode:userBill.productCode,
      quantity:userBill.quantity
    }
    return this.Http.post<IUserId>(this.urlsort,detail)
  }

}
